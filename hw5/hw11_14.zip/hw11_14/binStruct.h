//
// Created by noah holt on 2/17/23.
//

#include <iostream>

using namespace std;

#ifndef HW11_14_BINSTRUCT_H
#define HW11_14_BINSTRUCT_H

namespace productBinStruct
{

    struct productBin{

        string itemName;
        int numberInHouse;

    };

}

#endif //HW11_14_BINSTRUCT_H
