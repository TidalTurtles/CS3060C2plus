
#include <iostream>
#include <iomanip>
using namespace std;

//prototype
double profit(double, double, double);

int main() {

    //vars
    int numShares;
    double purchasePrice;
    double purchaseCommission;
    double salePrice;
    double saleCommission;
    double profit;

    //get num shares
    cout << "How many shares did you buy? ";
    cin >> numShares;

    //get purchase price of share
    cout << "What was the purchace Price? ";
    cin >> purchasePrice;

    //get purchase commission

    //get sales price

    //get sales commission

    //profit or loss

    //display result

    return 0;

}
