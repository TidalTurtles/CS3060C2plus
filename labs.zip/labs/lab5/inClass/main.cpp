/*
 *
 * Noah Holt
 *
 * Lab day 4: 12.11, 12.15, 13.3* 13.4*
 *
 */

#include <iostream>

int main() {



    return 0;

}
