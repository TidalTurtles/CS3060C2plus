//
// Created by noah holt on 3/1/23.
//


#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <iomanip>

using namespace std;

//func prototypes


int main() {

    //get

    return 0;

}